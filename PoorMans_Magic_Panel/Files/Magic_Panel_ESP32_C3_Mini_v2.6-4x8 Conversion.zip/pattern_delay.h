/*
 * Pattern Delay Helper
 * Custom delay function to allow patterns to break immediately if serial commands arrive
 */

#ifndef PATTERN_DELAY_H
#define PATTERN_DELAY_H

#include <Arduino.h>

namespace LedControl {
  inline bool checkSerialAbort(unsigned long ms) {
    unsigned long start = millis();
    while (millis() - start < ms) {
      if (Serial.available() > 0) {
        char c = Serial.peek();
        if (c == ':' || c == '*' || c == '?' || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
          return true;
        }
      }
      if (Serial1.available() > 0) {
        char c = Serial1.peek();
        if (c == ':' || c == '*' || c == '?' || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
          return true;
        }
      }
      yield();
    }
    return false;
  }
}

#endif // PATTERN_DELAY_H
