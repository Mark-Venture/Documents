# Magic Panel ESP32-C3 — 4x8 Conversion

This firmware has been modified from the original 8x8 (64 LED) version to support a **4-wide × 8-tall (32 LED)** WS2812 matrix panel on an **AITRIP ESP32-C3 Mini** development board.

## What Changed

### Core Constants (`config.h`)
- `NUM_LEDS`: 64 → 32
- `MATRIX_WIDTH`: 8 → 4
- `MATRIX_HEIGHT`: unchanged (8)
- Added `isPatternDisabled()` function to gate patterns that require an 8x8 panel

### Disabled Patterns
The following 13 patterns require 8-pixel-wide static shapes (sprites, digits, logos) and are disabled on the 4-wide panel. They print a "disabled" message if invoked and are marked `[DISABLED]` in the `LIST` output:

| ID | Pattern | Reason |
|----|---------|--------|
| 20 | Cross | 8x8 bitmap |
| 33 | AI Logo | 8x8 bitmap |
| 34 | 2GWD Logo | 8x8 bitmap |
| 40 | Countdown 9-0 | 8-wide digit bitmaps |
| 41 | Countdown 3-0 | 8-wide digit bitmaps |
| 44 | Smiley Face | 8x8 bitmap |
| 45 | Sad Face | 8x8 bitmap |
| 46 | Heart | 8x8 bitmap |
| 56 | Animated Heart | 8x8 bitmap |
| 63 | 3D Cube | 8x8 rendering grid |
| 67 | Pac-Man | 8x8 sprites |
| 68 | Space Invaders | 8x8 sprites |
| 80 | Bouncing Text | Static text display too wide |

The original pattern code and sprite data are preserved in the source — nothing was deleted. To re-enable for an 8x8 panel, change `MATRIX_WIDTH` back to 8, `NUM_LEDS` back to 64, restore the bitmasks, and remove the `isPatternDisabled()` function.

### Bitmask Updates (`patterns_effects.h`)
All expand/compress/ring effect bitmasks were recalculated for 4 columns. The `setRow()` function maps columns to bits as: col 0 → bit 7, col 1 → bit 6, col 2 → bit 5, col 3 → bit 4. So:
- `B11110000` = all 4 columns on
- `B01100000` = center 2 columns (cols 1, 2)
- `B10010000` = edge columns only (cols 0, 3)

Flash vertical and flash quadrant patterns now split at `MATRIX_WIDTH / 2` (column 2) instead of the hardcoded column 4.

### Perimeter Walks (`patterns_animations.h`)
The `oneLoop` and `twoLoop` animations traced a hardcoded 28-step path around the 8x8 border. These now compute the perimeter length as `2 * MATRIX_WIDTH + 2 * MATRIX_HEIGHT - 4` (= 20 for 4x8) and use dimension-based breakpoints for the path segments.

### VU Meter (`patterns_animations.h`)
Level caps changed from hardcoded `8` to `MATRIX_HEIGHT`.

### Quadrant Patterns (`patterns_shapes.h`)
Quadrant origin coordinates and fill sizes now use `MATRIX_WIDTH/2` and `MATRIX_HEIGHT/2` instead of hardcoded `4`. Checkerboard pattern uses `MATRIX_WIDTH` for row calculation instead of `8`.

### Astromech/PSI Patterns (`patterns_astromech.h`)
- Spiral march color cycling uses `MATRIX_WIDTH` instead of `8`
- R2-D2 Thinking pattern computes center from dimensions instead of hardcoded `3.5`
- R2-D2 Alert quadrant split uses `MATRIX_WIDTH / 2` and `MATRIX_HEIGHT / 2`

### Raindrops (`patterns_effects.h`)
Random coordinate generation uses `MATRIX_WIDTH` and `MATRIX_HEIGHT` instead of `8`.

### Startup Animation (`.ino`)
The version number digit display (which required 8-wide digit bitmaps) was replaced with a flash sequence: 2 flashes, pause, 6 flashes — representing version 2.6.

### Smart Demo (`.ino`)
Removed all disabled pattern IDs from the curated demo pattern list.

### Test All Patterns (`.ino`)
Skips disabled patterns with a "SKIPPED (requires 8x8)" message.

## Files NOT Modified
These files required no changes — they already use `MATRIX_WIDTH`, `MATRIX_HEIGHT`, and `NUM_LEDS` constants throughout:
- `led_control.h`
- `command_processor.h`
- `patterns_basic.h`
- `patterns_trace.h`
- `patterns_text.h` (text scrolling works on any width)

## Hardware
- **Board:** AITRIP ESP32-C3 Mini (or any ESP32-C3 Mini variant)
- **LED Pin:** GPIO 6
- **External Serial:** GPIO 20 (RX) / GPIO 21 (TX) at 115200 baud
- **I2C Address:** 20 (configurable)
- **LED Panel:** 32 WS2812 LEDs in 4-column × 8-row progressive/scanline layout
